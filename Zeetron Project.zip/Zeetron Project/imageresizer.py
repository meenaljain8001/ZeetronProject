from PIL import Image
img = Image.open("3.jpg")
size = (1800,800)
img.thumbnail(size)
img.save("3_new.jpg")