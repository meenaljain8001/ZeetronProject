n = int(input())
a = []
a = [int(input()) for i in range(n)]

k = int(input())

while k>0:
    t = a[n-1]
    for j in range(1,n):
        a[n-j] = a[n-j-1]
    a[0] = t
    k=k-1

print(a)