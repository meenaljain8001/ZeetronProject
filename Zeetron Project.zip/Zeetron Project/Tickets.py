a = int(input())
for q in range(a):
    c = 1
    s = input()
    i=0
    for i in range(0,len(s),2):
        if(s[i]!=s[0]):
            c=0

    for i in range(1,len(s),2):
        if(s[1]!=s[i]):
            c=0
    if(s[0]==s[1]):
            c=0
    if(c==0):
        print("NO\n")
    else:
        print("YES\n")

