from PIL import Image
img = Image.open('1.jpg')
size=(1800,800)
img.thumbnail(size)
img.save("1_new.jpg")